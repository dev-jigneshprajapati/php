<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Description of ContactController
 *
 * @author jignesh
 */
class RestgetController extends CI_Controller {

    function __construct() {
        parent::__construct();
    }

    public function allcontacts() {

        $query = $this->db->get("contact");
        $data['data'] = $query->result();
        $data['total'] = $this->db->count_all("contact");
        echo json_encode($data);
    }

    public function addcontact() {
        $_POST = json_decode(file_get_contents("php://input"), true);
        
        $data = array(
        'contact_name' => $this->input->post('contact_name'),
        'contact_address' => $this->input->post('contact_address'),
        'contact_phone' => $this->input->post('contact_phone')
        );

        $this->db->set($data);
        $this->db->insert('contact', $data);
    }

    public function viewcontact($contact_id) {

        $q = $this->db->get_where('contact', array('contact_id' => $contact_id));
        echo json_encode($q->row());
    }

    public function updatecontact() {
        $_POST = json_decode(file_get_contents("php://input"), true);
        
        $contact_id = $this->input->post('contact_id');
        $data = array(
            'contact_name' => $this->input->post('contact_name'),
            'contact_address' => $this->input->post('contact_address'),
            'contact_phone' => $this->input->post('contact_phone')
        );
        
        $this->db->set($data);
        $this->db->where('contact_id', $contact_id);
        $this->db->update('contact', $data);
        $q = $this->db->get_where('contact', array('contact_id' => $contact_id));
        echo json_encode($q->row());
    }

    public function deletecontact($contact_id) {

        $this->db->where('contact_id', $contact_id);
        $this->db->delete('contact');
        echo json_encode(['success' => true]);
    }

}

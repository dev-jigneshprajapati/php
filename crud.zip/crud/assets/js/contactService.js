/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

'use strict';

angular.module('myCrudApp').factory('ContactService',['$http', '$q', function($http, $q){

    var REST_SERVICE_URI = 'http://localhost/crud/index.php/';
    
    var factory = {
        findAllContacts : findAllContacts,
        createContact : createContact,
        updateContact : updateContact,
        deleteContact : deleteContact
    };
    
    return factory;
    
    
    function findAllContacts(){
        var deferred = $q.defer();
        $http.get(REST_SERVICE_URI+'restgetcontroller/allcontacts')
                .then(
                    function (response){
                        deferred.resolve(response.data);
                    },
                    function (error){
                        console.error("Error while fetching contacts");
                        deferred.reject(error);
                    }
                );
        return deferred.promise;
    }
    
    function createContact(contact){
        var deferred = $q.defer();
        $http.post(REST_SERVICE_URI+'restgetcontroller/addcontact/', contact)
                .then(
                    function (response){
                        deferred.resolve(response.data);
                    },
                    function (error){
                        console.error("Error while creating contacts");
                        deferred.reject(error);
                    }
                );
        return deferred.promise;
    }
    
    function updateContact(contact){
        var deferred = $q.defer();
        $http.post(REST_SERVICE_URI+'restgetcontroller/updatecontact/', contact)
                .then(
                    function (response){
                        deferred.resolve(response.data);
                    },
                    function (error){
                        console.error("Error while updating contacts");
                        deferred.reject(error);
                    }
                );
        return deferred.promise;
    }
    
    function deleteContact(id){
        var deferred = $q.defer();
        $http.delete(REST_SERVICE_URI+'restgetcontroller/deletecontact/'+id)
                .then(
                    function (response){
                        deferred.resolve(response.data);
                    },
                    function (error){
                        console.error("Error while deleting contacts");
                        deferred.reject(error);
                    }
                );
        return deferred.promise;
    }
    
        
}]);



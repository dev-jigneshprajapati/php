/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

'use strict';

angular.module('myCrudApp').controller('ContactController', ['$scope', 'ContactService', function ($scope, ContactService) {

        var self = this;
        self.contact = {contact_id: null, contact_name: '', contact_address: '', contact_phone: ''};
        self.contacts = [];

        self.submit = submit;
        self.update = update;
        self.remove = remove;
        self.reset = reset;

        findAllContacts();

        function findAllContacts() {
            ContactService.findAllContacts()
                    .then(
                            function (d) {
                                self.contacts = d;
                            },
                            function (error) {
                                console.error("Error while fetching contacts");
                            }
                    );
        }
                
        function createContact(contact){
            ContactService.createContact(contact)
                    .then(
                            findAllContacts,
                            function (error) {
                                console.error("Error while creating contacts");
                            }
                    );
        }
                
        function updateContact(contact){
            ContactService.updateContact(contact)
                    .then(
                            findAllContacts,
                            function (error) {
                                console.error("Error while updating contacts");
                            }
                    );
        }
                
        function deleteContact(id){
            ContactService.deleteContact(id)
                    .then(
                            findAllContacts,
                            function (error) {
                                console.error("Error while deleting contacts");
                            }
                    );
        }

        function submit(){
            if(self.contact.contact_id === null){
                console.log("Saving New Contact :", self.contact);
                createContact(self.contact);
            }else{
                updateContact(self.contact);
                console.log("Contact Update With ID :", self.contact.contact_id);
            }
            reset();
        }
        
        function update(id){
            console.log("id to be updated ", id);
            self.contact = angular.copy(id);
        }
        
        function remove(id){
            console.log("id to be removed ", id);
            
            if(self.contact.contact_id === id){//clean form if the contact to be deleted is shown there.
                reset();
            }
            deleteContact(id);
        }

        function reset(){
            self.contact = {contact_id: null, contact_name: '', contact_address: '', contact_phone: ''};
            $scope.myForm.$setPristine(); //reset Form
        }

    }]);


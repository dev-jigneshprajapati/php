<?php
$DBHOST = 	"localhost";
$DBNAME =	"test";
$DBUSER	=	"root";
$DBPASS	=	"";

try{
	$con = new PDO("mysql:host={$DBHOST};dbname={$DBNAME}", $DBUSER, $DBPASS);
}
// show error
catch(PDOException $exception){
    echo "Connection error: " . $exception->getMessage();
}

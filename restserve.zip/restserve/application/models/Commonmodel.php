<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Commonmodel extends CI_Model {

    function __construct() {

        parent::__construct();

        $this->load->database();
    }

    public function formatDateDB($strDate) {

        $strDate = date('Y-m-d H:i:s', strtotime($strDate));

        return $strDate;
    }

    public function uploadImageFile($strControlName, $strUploadPath, $intRecordId, $strUploadFor, $blnResizeImage = false, $imgWidth = "", $imgHeight = "") {

        $arrFile = $_FILES[$strControlName];

        $arrFileInfo = pathinfo($arrFile['name']);

        $strExtension = $arrFileInfo['extension'];

        $strUplaodFileName = $intRecordId . "." . $strExtension;

        $arrConfig['upload_path'] = $strUploadPath;

        $arrConfig['allowed_types'] = 'gif|jpg|png';

        $arrConfig['file_name'] = $strUplaodFileName;

        $arrConfig['overwrite'] = true;

        $this->load->library('upload', $arrConfig);

        $this->upload->initialize($arrConfig);

        if (!$this->upload->do_upload($strControlName)) {

            $error = array('error' => $this->upload->display_errors());

            return false;
        } else {

            $image_data = $this->upload->data();

            if ($blnResizeImage == true) {

                $config = array(
                    'source_image' => $image_data['full_path'],
                    'new_image' => $strUploadPath,
                    'maintain_ration' => true,
                    'width' => $imgWidth,
                    'height' => $imgHeight
                );

                $this->load->library('image_lib', $config);

                $this->image_lib->initialize($config);

                $this->image_lib->resize();
            }

            // Insert Upload Record

            $arrRecord['original_file_name'] = $arrFileInfo['basename'];

            $arrRecord['uploaded_file_name'] = $strUplaodFileName;

            $arrRecord['upload_for'] = $strUploadFor;

            $arrRecord['record_id'] = $intRecordId;

            // Insert Entry into Uploads Table

            $strQuery = "INSERT INTO uploads (" . implode(",", array_keys($arrRecord)) . ")

						VALUES ('" . implode("','", array_values($arrRecord)) . "')";

            $this->db->query($strQuery);


            return $this->db->insert_id();
        }
    }


    function getByID($strTable, $colname, $value) {

        $this->db->where($colname, $value);

        $rsReturn = $this->db->get($strTable)->result_array();

        return $rsReturn[0];
    }

    function getRecords($strTableName, $columns = "", $where = "", $order = "") {

        if ($columns != '')
            $this->db->select($columns);



        if ($where != '')
            $this->db->where($where);



        if ($order != '')
            $this->db->order_by($order);



        return $this->db->get($strTableName)->result();
    }

    function getRecordsArray($strTableName, $columns = "", $where = "", $order = "") {

        if ($columns != '')
            $this->db->select($columns);



        if ($where != '')
            $this->db->where($where);



        if ($order != '')
            $this->db->order_by($order);



        return $this->db->get($strTableName)->result_array();
    }

    function getRecord($strTableName, $columns = "", $where = "", $order = "") {

        if ($columns != '')
            $this->db->select($columns);



        if ($where != '')
            $this->db->where($where);



        if ($order != '')
            $this->db->order_by($order);



        return $this->db->get($strTableName)->result_array();
    }

    function insert($tbl, $record) {

        $this->db->insert($tbl, $record);

        return $this->db->insert_id();
    }

    function update($strTableName, $record, $arrWhere) { 
        //$this->db->where($where);
        $this->db->update($strTableName, $record, $arrWhere);
    }

    function delete($strTable, $colname, $value) {

        $this->db->where($colname, $value);

        $this->db->delete($strTable);
    }

    function checkLogin($strUsername, $strPassword) {

        $where = array('type' => 'Admin', 'email' => $strUsername, 'password' => $strPassword);

        $this->db->select('*');

        $this->db->from('tbl_user');

        $this->db->where($where);

        $query = $this->db->get();

        $result = $query->result_array();

        if (!empty($result)) {

            return $result[0];
        } else {

            return $result;
        }
    }

    


    // locationlist

    public function memberlist($id = '', $status = 'Active', $printCityId = '') {


        if ($printCityId != '') {
            $this->db->where(array('printCityId' => $printCityId));
        }
        if ($id != '') {

            return $this->db->get_where('tbl_user', array('id' => $id, 'type' => 'member', 'status' => $status))->result();
        } else {

            return $this->db->get_where('tbl_user', array('type' => 'member', 'status' => $status))->result();
        }
    }

    public function memberProductlist($id) {

        return $this->db->get_where('user_product_price', array('user_id' => $id))->result();
    }

    public function jobWork($id = '', $printCityId = '') {

        $where = '';
        if ($id != '') {
            $where .= 'where j.id = "' . $id . '"';
        }
        if ($printCityId != '') {
            $where .= 'left join tbl_user u  on u.id = j.user_id where u.printCityId = "' . $printCityId . '"';
        }

        $strQuery = "select j.* from job_master j " . $where;
        $rsResult = $this->db->query($strQuery);
        return $rsResult->result();
    }

    public function jobWorkByUser($userID = '') {

        if ($userID > 0) {
            $this->db->order_by("id", "desc");
            return $this->db->get_where('job_master', array('user_id' => $userID))->result();
        } else {
            $this->db->order_by("id", "desc");
            return $this->db->get("job_master")->result();
        }
    }

    public function jobByUser($userID = '', $startDate = '', $endDate = '', $productId = '', $masterCityId = '') {

        if ($userID != 99999999 && ($startDate != '' && $endDate != '') && $productId != '') {
            $where = 'where';
            $where .= ' user_id =' . $userID . ' and (DATE(job_date) BETWEEN "' . $startDate . '" and "' . $endDate . '") and  products  like "%' . $productId . '%" ';
        } else if ($userID != 99999999) {
            $where = 'where';
            $where .= ' user_id =' . $userID;
        } else if ($startDate != '' && $endDate != '') {
            $where = 'where';
            $where .= ' (DATE(job_date) BETWEEN "' . $startDate . '" and "' . $endDate . '") and  products  like "%' . $productId . '%" ';
        }

        $leftJoin = '';
        $leftJoinwhere = '';
        if ($masterCityId != '') {
            $leftJoin .= ' LEFT JOIN tbl_user u on u.id = job_master.user_id ';
            $leftJoinwhere .= 'AND printCityId ="' . $masterCityId . '"';
        }

        $strQuery = "select job_master.* from job_master  " . $leftJoin . $where . $leftJoinwhere . " order by id desc";
        $rsResult = $this->db->query($strQuery);
        $rsRecord = $rsResult->result();
        return $rsRecord;
    }

    public function doesRecordExist($table, $condKey, $condValue) {

        try {

            $strQuery = "SELECT COUNT(*) as CNT FROM $table WHERE $condKey = '$condValue'";

            $rsResult = $this->db->query($strQuery);

            $rsRecord = $rsResult->result_array();

            return $rsRecord[0]['CNT'];
        } catch (PDOException $e) {

            echo 'ERROR: ' . $e->getMessage() . 'in doesRecordExist';
        }
    }

    public function customQuery($strQuery) {

        $rsResult = $this->db->query($strQuery);

        $rsRecord = $rsResult->result_array();

        return $rsRecord;
    }

    public function getSerachData($tableName, $columns, $keyword) {

        $strQuery = "select * from $tableName where $columns like'%$keyword%'";

        $rsResult = $this->db->query($strQuery);

        $rsRecord = $rsResult->result_array();

        return $rsRecord;
    }

    public function fileUpload($path, $filename, $tmp_file) {

        if (!file_exists($path)) {

            mkdir($path, 0777, true);
        }

        if (move_uploaded_file($tmp_file, $path . $filename)) {

            return $path . $filename;
        } else {

            return "0";
        }
    }

    function mailSend($to, $subject, $htmldata) {

        ini_set("SMTP", "aspmx.l.google.com");
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";
        $headers .= "From: karanmultiprint.in<karanmultiprints@gmail.com>" . "\r\n";
        $headers .= "bcc: karanmultiprint.in<jigneshjoy@gmail.com>" . "\r\n";
        $mail = mail($to, $subject, $htmldata, $headers);
        if ($mail) {
            $mail = "Send Mail Successfully...";
        } else {
            $mail = "Something goes wrong, please try again...";
        }
        return $mail;
    }

    function smtpMailSend($to, $subject, $htmldata) {

//        $this->load->library('email');
        $config['protocol'] = "smtp";
        $config['smtp_host'] = "ssl://smtp.gmail.com";
        $config['smtp_port'] = "465";
        $config['smtp_user'] = "karanmultiprints@gmail.com";
        $config['smtp_pass'] = "9099924654";
        $config['charset'] = "utf-8";
        $config['mailtype'] = "html";
        $config['newline'] = "\r\n";

        $this->email->initialize($config);

        $this->email->from('karanmultiprints@gmail.com', 'karanmultiprint.in');
//        $list = array('jigneshjoy@gmail.com','riteshrk1@gmail.com');
        $this->email->to($to);
        $this->email->bcc('jigneshjoy@gmail.com', 'danger');
//            $this->email->bcc($list);
//            $this->email->reply_to('my-email@gmail.com', 'Explendid Videos');
        $this->email->subject($subject);
        $this->email->message($htmldata);
        $mail = $this->email->send();
        if ($mail) {
            $mail = "Send Mail Successfully...";
        } else {
            $mail = "Something goes wrong, please try again...";
        }
        return $mail;
    }

    public function getProductTypeCombo($strControlName, $strExtraParams = "", $strValue = "") {

        $strQuery = "SELECT id,name FROM product_type";
        $rsResult = $this->db->query($strQuery);
        $rsRecord = $rsResult->result_array();

        $strHtml = '';


        $strHtml .= '<select class="form-control" name="' . $strControlName . '" id="' . $strControlName . '"  ' . $strExtraParams . ' required="" >';
        $strHtml .= '<option value="">Select Type</option>';
        foreach ($rsRecord as $value) {
            $selected = '';
            if ($strValue == $value['id']) {
                $selected = 'selected';
            }
            $strHtml .= '<option value="' . $value['id'] . '" ' . $selected . ' >' . $value['name'] . '</option>';
        }

        $strHtml .= '</select>';

        return $strHtml;
    }
}

/* End of file city.php */

/* Location: ./application/models/Fyimodel.php */
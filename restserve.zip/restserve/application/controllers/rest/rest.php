<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Example
 *
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array.
 *
 * @package		CodeIgniter
 * @subpackage	Rest Server
 * @category	Controller
 * @author		Phil Sturgeon
 * @link		http://philsturgeon.co.uk/code/
 */
// This can be removed if you use __autoload() in config.php OR use Modular Extensions
require APPPATH . '/libraries/REST_Controller.php';

class Rest extends REST_Controller {

    function user_get() {
        $table = 'emp_copy';

        if (!$this->get('id')) {
            $this->response(NULL, 400);
        }

        echo $this->get('id');
        $users = $this->Commonmodel->getByID($table, "id", $this->get('id'));

        $user = @$users[$this->get('id')];

        if ($user) {
            $this->response($user, 200); // 200 being the HTTP response code
        } else {
            $this->response(array('error' => 'User could not be found'), 404);
        }
    }

    function user_post() {

        $id = $_POST['id'];
        
        if(count($id) > 0){
//            update Record
            $arrWhere = array("id" => $id);
            $arrData = array(
                "ename" => $this->input->post('ename'),
                "job" => $this->input->post('job'),
                "sal" => $this->input->post('sal')
            );
            $users = $this->Commonmodel->update('emp_copy', $arrData, $arrWhere);
            $message = array('update_id' => $id, 'message' => 'UPDATED!');
        }else{
//            Insert recorrd
            if (count($_FILES) > 0) {
            $path = "assets/upload/";
            
            $fileName = $_FILES['img']['name'];
            $file_tmp = $_FILES['img']['tmp_name'];
            
            $fName = preg_replace('/_+/', '_', $fileName);
            $fileUploads = $this->Commonmodel->fileUpload($path, $fName, $file_tmp);

            if ($fileUploads) {
                $arrData = array(
                    "ename" => $this->input->post('ename'),
                    "job" => $this->input->post('job'),
                    "sal" => $this->input->post('sal'),
                    "img" => $fName,
                );
                $users = $this->Commonmodel->insert('emp_copy', $arrData);
                $message = array('insert_id' => $users, 'message' => 'FILE ADDED!');
            } else {
                $message = array('message' => 'errro!');
            }
        } else {
            $arrData = array(
                "ename" => $this->input->post('ename'),
                "job" => $this->input->post('job'),
                "sal" => $this->input->post('sal')
            );
            $users = $this->Commonmodel->insert('emp_copy', $arrData);
            $message = array('insert_id' => $users, 'message' => 'ADDED!');
        }
        }
        
        

        $this->response($message, 200); // 200 being the HTTP response code
    }
    
    function user_delete() {
        //$this->some_model->deletesomething( $this->get('id') );
        $this->Commonmodel->delete('emp_copy', 'id', $this->get('id'));

        $message = array('id' => $this->get('id'), 'message' => 'DELETED!');

        $this->response($message, 200); // 200 being the HTTP response code
    }

    function users_get() {
        $users = $this->Commonmodel->getRecords('emp_copy');

        if ($users) {
            $this->response($users, 200); // 200 being the HTTP response code
        } else {
            $this->response(array('error' => 'Couldn\'t find any users!'), 404);
        }
    }

}
